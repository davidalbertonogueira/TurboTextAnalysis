#!/bin/bash

cd release
make